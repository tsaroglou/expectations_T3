from otree.api import *
from random import choice, random
import time

doc = """
Your app description
"""
def bernoulli(p):
    num = 0

    while True:
        if random() < p:
            num += 1
        else:
            return num


class C(BaseConstants):
    NAME_IN_URL = 'Game'
    PLAYERS_PER_GROUP = 2
    NUM_BASE = 20
    NUM_ROUNDS_1 = NUM_BASE + bernoulli(0.5)
    NUM_ROUNDS_2 = NUM_BASE + bernoulli(0.5)
    NUM_ROUNDS= NUM_ROUNDS_1 + NUM_ROUNDS_2

    print("Rounds:", NUM_ROUNDS_1, NUM_ROUNDS_2)
    CONTRIBUTION = 60
    MULTIPLIER = 2
    NUM_PLAYERS = 3
    CHOICES = [[True, 'I would like to contribute my income to the common pool'], [False, 'I would like to keep my income for myself']]


class Subsession(BaseSubsession):
   pass


class Group(BaseGroup):
    num_human_contributors = models.IntegerField(initial=0)
    num_overall_contributors = models.IntegerField(initial=0)
    payoff = models.FloatField(initial=0)
    individual_share = models.FloatField(initial=0)
    bot_payoff = models.FloatField(initial=0)
    bot_contributed = models.BooleanField(initial=False)


class Player(BasePlayer):
    wait_page_arrival= models.FloatField(initial=0)
    waiting_too_long= models.BooleanField(initial=False)
    participation_fee= models.FloatField(initial=3)
    has_contributed = models.BooleanField(choices=C.CHOICES, widget=widgets.RadioSelect, label="")
    actual_round_number = models.IntegerField(initial=1)
    study_type = models.IntegerField(initial=1)
    
    start_time = models.FloatField(initial=0)
    unpaired = models.BooleanField(initial=False)
    time_out_happened = models.BooleanField(initial=False)
    left_hanging = models.BooleanField(initial=False)
    dropped_out = models.BooleanField(initial=False)
    points_in_session_2 = models.IntegerField(initial=0)
   
    age = models.IntegerField(label="What is your age?", choices=[[i, str(i)] for i in range(18, 100)])
    
    gender = models.IntegerField(label="What gender do you identify as?", 
                                 choices=[[1, 'Male'], [2, 'Female'], [3, 'Other'], [4, 'Prefer not to say']])
    
    income = models.IntegerField(label="What is the total combined monthly income of your household, after taxes?", 
                                 choices=[[1, '<1000'], [2, '1000-3000'], [3, '3000-5000'], [4, '>5000'], [5, 'Prefer not to say']])
    
    education = models.IntegerField(label="What is your highest level of education?", 
                                    choices=[[1, 'No formal education'], [2, 'GCSE or equivalent'], [3, 'A-Levels or equivalent'], [4, 'Undergraduate degree'], [5, 'Postgraduate degree'], [6, 'Other'], [7, 'Prefer not to say']])
    
    comment1 = models.LongStringField(label='Did you experience any technical difficulties while participating in this study? If so, which?')
    comment2 = models.LongStringField(label='Did you find the instructions to be clear? If not, please specify which part you found hard to understand.')
    comment3 = models.LongStringField(label='Could you briefly describe which strategy you chose during the two sessions?')
    comment4 = models.LongStringField(label='Could you briefly describe how you perceived the strategy of the other two participants?')
    comment5 = models.LongStringField(label='Do you have any further thoughts or feedback? ')


def group_by_arrival_time_method(subsession, waiting_players):
    print(waiting_players)
    if len(waiting_players) >= 2:
        return waiting_players[:2]
    for player in waiting_players:
        print(time.time(), player.participant.wait_page_arrival)
        if time.time() - player.participant.wait_page_arrival > 5 * 60:
            player.unpaired = True
            return [player]


def set_payoffs(group):
    players = group.get_players()
    round_number = players[0].round_number

    num_contributors_this_round = 0
    for player in players:
        if player.has_contributed:
            num_contributors_this_round += 1
    group.num_human_contributors = num_contributors_this_round
    group.num_overall_contributors = num_contributors_this_round

    if round_number in [1, C.NUM_ROUNDS_1 + 1]:
        print("Bot defected by default")
        bot_cooperate_prob = 0
    else:
        bot_cooperate_prob = group.in_round(round_number - 1).num_human_contributors / 3.0

    group.bot_contributed = random() < bot_cooperate_prob
    if group.bot_contributed:
        group.num_overall_contributors += 1

    group.individual_share = C.MULTIPLIER * C.CONTRIBUTION * group.num_overall_contributors / C.NUM_PLAYERS
    
    for player in players:
        if player.has_contributed:
            player.payoff =  group.individual_share
        else:
            player.payoff = C.CONTRIBUTION + group.individual_share

    if group.bot_contributed:
        # If the bot contributed, it only gets the group share
        group.bot_payoff = group.individual_share
    else:
        # If the bot did not contribute, it gets the group share plus its initial contribution
        group.bot_payoff = C.CONTRIBUTION + group.individual_share        


class Pairing_Waitpage(WaitPage):   
    group_by_arrival_time = True
    title_text = "Waiting to be grouped"
    body_text = "The study will start soon. Please wait until other participants are ready to interact with you in this study. You will wait a maximum of 5 minutes. If no other participant arrives during this time, you will not be able to start this game. You must stay on this page and be ready to participate in order to be eligible for a bonus. Thank you!"
    
    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == 1

class Gapfiller(Page):
    @staticmethod
    def is_displayed(player):
        if player.round_number == 1:
            # required for tracking the start time for the first round only
            player.participant.response_times = []
            player.participant.contribute_start_time = time.time()
            return True
        return False

class Unpaired(Page):
    @staticmethod
    def is_displayed(player):
        return player.unpaired


class Contribute(Page):
    form_model = "player"
    form_fields = ["has_contributed"]

    timer_text = 'If you stay inactive for too long you will be considered a dropout:'
    timeout_seconds = 3 * 60

    @staticmethod
    def vars_for_template(player):
        if player.round_number <= C.NUM_ROUNDS_1:
            player.actual_round_number = player.round_number
        else:
            player.actual_round_number = player.round_number - C.NUM_ROUNDS_1
            
        print(player.actual_round_number)
        return {'actual_round_number': player.actual_round_number} 
    
    @staticmethod
    def before_next_page(player, timeout_happened):
        if timeout_happened:
            this_player = player
            other_player = player.get_others_in_group()[0]
            
            this_player.dropped_out = True
            other_player.left_hanging = True
        else:
            player.participant.response_times.append(time.time() - player.participant.contribute_start_time)
            print(player.participant.response_times)
    

class Lefthanging(Page):
    @staticmethod
    def is_displayed(player):
        return player.left_hanging
    
    
class DroppedOut(Page):
    @staticmethod
    def is_displayed(player):
        return player.dropped_out

    
class Results_WaitPage(WaitPage):

    after_all_players_arrive = set_payoffs

    template_name = 'Game/Results_Waitpage.html'
    


class Results(Page):
    
    timer_text = 'If you stay inactive for too long you will be considered a dropout:'
    timeout_seconds = 3 * 60

    @staticmethod
    def vars_for_template(player):
        group = player.group
        bot_payoff = group.bot_payoff if group.bot_contributed else C.CONTRIBUTION + group.individual_share

        if player.round_number <= C.NUM_ROUNDS_1:
            player.actual_round_number = player.round_number
        else:
            player.actual_round_number = player.round_number - C.NUM_ROUNDS_1
            player.study_type = 2

        players_results = [
            {
                'id_in_group': "You" if p == player else f"Decision-Maker {p.id_in_group}",
                'has_contributed': p.has_contributed,
                'individual_share': int(group.individual_share),
                'payoff': p.payoff,
                "actual_round_number": p.actual_round_number
            }
            for p in group.get_players()
        ]
        total_pool = group.num_overall_contributors * C.CONTRIBUTION

        # Determine the bot's label based on the round number
        bot_label = 'Decision-Maker 3' if player.round_number <= C.NUM_ROUNDS_1 else 'Bot'

        bot_result = {
            'id_in_group': bot_label,
            'has_contributed': group.bot_contributed,
            'individual_share': int(group.individual_share),
            'payoff': int(bot_payoff),
        }

        players_results.append(bot_result)

        return {'players_results': players_results, 'total_pool': total_pool} 
    
    
    @staticmethod
    def before_next_page(player, timeout_happened):
        if timeout_happened:
            this_player = player
            other_player = player.get_others_in_group()[0]
            
            this_player.dropped_out = True
        else:
            player.participant.contribute_start_time = time.time()
            
    

class Instructions_Part2(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS_1
    

class Gapfillerpage_Part2(Page):
    @staticmethod
    def is_displayed(player):
        if player.round_number == C.NUM_ROUNDS_1:
            # required for tracking the start time for the first round only
            player.participant.contribute_start_time = time.time()
            return True
        return False


class Summary_Results(Page):
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS
    
    @staticmethod
    def vars_for_template(player):
        group = player.group
        player_id = player.id_in_group
       
        outputs = []
        total = 0
        
        # Adjust the round range to reflect session 2 rounds
        session_2_start = C.NUM_ROUNDS_1 + 1  # Session 2 starts after session 1
        session_2_end = C.NUM_ROUNDS          # The last round is the end of session 2

        for round_number in range(session_2_start, session_2_end + 1):
            this_round_dict = {}
            this_round_dict["round_number"] = round_number - C.NUM_ROUNDS_1  # Normalize round number for session 2
            
            group_for_this_round = group.in_round(round_number)
            player_for_this_round = group_for_this_round.get_player_by_id(player_id)
            
            if player_for_this_round.has_contributed:
                this_round_dict["payoff"] = int(group_for_this_round.individual_share)
            else:
                this_round_dict["payoff"] = int(C.CONTRIBUTION + group_for_this_round.individual_share)
            
            total += this_round_dict["payoff"]
            outputs.append(this_round_dict)
        
        player.points_in_session_2 = total 
        
        return {"results": outputs, "total": int(total)}
  
    
class Demographics(Page):
    form_model = 'player'
    form_fields = ['age', 'gender', 'income', 'education', 'comment1','comment2','comment3','comment4','comment5']
        
    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS


class Payment(Page):
    @staticmethod
    def vars_for_template(player):
        group = player.group
        player_id = player.id_in_group
        
        outputs = []
        total = 0
        
        # Adjust the round range to reflect session 2 rounds
        session_2_start = C.NUM_ROUNDS_1 + 1  # Session 2 starts after session 1
        session_2_end = C.NUM_ROUNDS          # The last round is the end of session 2

        for round_number in range(session_2_start, session_2_end + 1):
            this_round_dict = {}
            this_round_dict["round_number"] = round_number - C.NUM_ROUNDS_1  # Normalize round number for session 2
            
            group_for_this_round = group.in_round(round_number)
            player_for_this_round = group_for_this_round.get_player_by_id(player_id)
            
            if player_for_this_round.has_contributed:
                this_round_dict["payoff"] = int(group_for_this_round.individual_share)
            else:
                this_round_dict["payoff"] = int(C.CONTRIBUTION + group_for_this_round.individual_share)
            
            total += this_round_dict["payoff"]
    
    # convert total points to pounds:

        converted_payoff = round(total / 2000, 2)


    # Add the participation fee
        participation_fee = int(player.participation_fee)  # Ensure this is defined for the player model

        # Compute final payment
        final_payment= converted_payoff + participation_fee

        return {
            "results": outputs,
            "total": int(total),
            "participation_fee": participation_fee,
            "final_payment": round(final_payment,2),
            "converted_payoff": round(converted_payoff,2)
        }  

    @staticmethod
    def is_displayed(player):
        return player.round_number == C.NUM_ROUNDS
    
class Redirection(Page):
    def is_displayed (player):
        return player.round_number == C.NUM_ROUNDS



page_sequence = [Pairing_Waitpage, Unpaired, Gapfiller, Contribute, Results_WaitPage, Lefthanging, DroppedOut, Results,
   Instructions_Part2, Gapfillerpage_Part2, Summary_Results, Demographics, Payment, Redirection]

