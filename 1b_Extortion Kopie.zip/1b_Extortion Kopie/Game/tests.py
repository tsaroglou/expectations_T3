from random import random

from otree.api import *
from . import *


class PlayerBot(Bot):
    def play_round(self):
        yield Gapfiller
        for _ in range(C.NUM_ROUNDS_1):
            yield Contribute, dict(has_contributed=random() < 0.8)
            yield Results
            
        yield Instructions_Part2
        yield Gapfillerpage_Part2
        for _ in range(C.NUM_ROUNDS_2):
            yield Contribute, dict(has_contributed=random() < 0.8)
            yield Results
            
        yield Summary_Results
        yield Demographics, dict(age=18, gender=1, income=1, education=1, comment1=" ", comment2=" ", comment3=" ", comment4=" ", comment5=" ")
        yield Payment
        yield Submission(Redirection, check_html=False)
        