from otree.api import *
from random import choice, random
import time

doc = """
Your app description
"""
def bernoulli(p):
    num = 0

    while True:
        if random() < p:
            num += 1
        else:
            return num


class C(BaseConstants):
    NAME_IN_URL = 'Instructions'
    PLAYERS_PER_GROUP = 2
    NUM_PLAYERS = 2
    NUM_ROUNDS = 1
    CONTRIBUTION = 60
    MULTIPLIER = 2
    CHOICES = [[True, '60 Points'], [False, '0 Points']]
    CORRECT_ANSWERS = {
        'Task0': 3,
        'Task1': 1, 
        'Task2': 2,  
        'Task3': 2, 
        'Task4': 3,  
        'Task5': 1,  
        'Task6': 2,  
        'Task7': 3,  
        'Task8': 2,  
        'Task9': 3, 
    }
    
    
class Subsession(BaseSubsession):
   pass


class Group(BaseGroup):
    num_human_contributors = models.IntegerField(initial=0)
    num_overall_contributors = models.IntegerField(initial=0)
    payoff = models.FloatField(initial=0)
    individual_share = models.FloatField(initial=0)
    bot_payoff = models.FloatField(initial=0)
    bot_contributed = models.BooleanField(initial=False)


class Player(BasePlayer):
    wait_page_arrival= models.FloatField(initial=0)
    waiting_too_long= models.BooleanField(initial=False)
    participation_fee= models.FloatField(initial=4)
    has_contributed = models.BooleanField(choices=C.CHOICES, widget=widgets.RadioSelect, label="I would like to contribute ")
    actual_round_number = models.IntegerField(initial=1)
    study_type = models.IntegerField(initial=1)
    num_errors = models.IntegerField(initial=0)
    
    start_time = models.FloatField(initial=0)
    unpaired = models.BooleanField(initial=False)
    time_out_happened = models.BooleanField(initial=False)
    left_hanging = models.BooleanField(initial=False)
    dropped_out = models.BooleanField(initial=False)
    
    Task0 = models.IntegerField(label='When will you find out which sessions included complete instructions?',
                                 choices=[[1, 'In the beginning of the first session.'],[2, 'In the beginning of the second session.'],[3, 'After completing both sessions.'], ], widget=widgets.RadioSelect) 
    Task1 = models.IntegerField(label='How many income points will each decision-maker receive at the beginning of each round',
                                 choices=[[1, '60 Points'],[2, '80 Points'],[3, '100 Points'], ], widget=widgets.RadioSelect)  
    Task2 = models.IntegerField(label='What is the chance that an additional round will follow after you interacted in the 20th round?',
                                 choices=[[1, '25 %'],[2, '50 %'],[3, '75 %'], ], widget=widgets.RadioSelect) 
    Task3 = models.IntegerField(label='What is the chance that an additional round will follow after you interacted in the 21st round?',
                                 choices=[[1, '25 %'],[2, '50 %'],[3, '75 %'], ], widget=widgets.RadioSelect) 
    Task4 = models.IntegerField(label='By what factor will the contributions to the common pool be multiplied?',
                                 choices=[[1, "0.5"],[2, "1"],[3, "2"], ], widget=widgets.RadioSelect)  
    Task5 = models.IntegerField(label='With which decision can you make sure you generate the most points for the group?',
                                 choices=[[1, 'By contributing my income'],[2, 'By keeping my income for myself'], ], widget=widgets.RadioSelect) 
    Task6 = models.IntegerField(label='With which decision you can make sure you earn the most points in this round personally?',
                                 choices=[[1, 'By contributing my income'],[2, 'By keeping my income for myself'], ], widget=widgets.RadioSelect)                              
    Task7 = models.IntegerField(label='In this example, what is the final payoff of each decision-maker?',
                                 choices=[[1, '180 Points'],[2, '60 Points'],[3, '120 Points'], ], widget=widgets.RadioSelect)
    Task8 = models.IntegerField(label='In this example, what is the final payoff of decision-maker 2?',
                                 choices=[[1, '60 Points'],[2, '80 Points'],[3, '140 Points'], ], widget=widgets.RadioSelect)  
    Task9 = models.IntegerField(label='In this example, what is the final payoff of decision-maker 3?',
                                choices=[[1, '60 Points'], [2, '80 Points'], [3, '140 Points']], widget=widgets.RadioSelect)



# PAGES
class ConsentForm(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1


class Instructions(Page):
    form_model = "player"
    form_fields = ["Task0"]

    @staticmethod
    def error_message(player, values):
        # Check if each task response matches the correct answer
        errors = []
        if values['Task0'] != C.CORRECT_ANSWERS['Task0']:
            errors.append('The answer to question 1 is incorrect.')
        if errors:
            player.num_errors += len(errors)
            return " ".join(errors)
        
    @staticmethod    
    def is_displayed(player):
        return player.round_number == 1 


class Instructions1(Page):
    form_model = "player"
    form_fields = ["Task1", "Task2", "Task3"]

    @staticmethod
    def error_message(player, values):
        # Check if each task response matches the correct answer
        errors = []
        if values['Task1'] != C.CORRECT_ANSWERS['Task1']:
            errors.append('The answer to question 1 is incorrect.')
        if values['Task2'] != C.CORRECT_ANSWERS['Task2']:
            errors.append('The answer to question 2 is incorrect.')
        if values['Task3'] != C.CORRECT_ANSWERS['Task3']:
            errors.append('The answer to question 3 is incorrect.')

        if errors:
            player.num_errors += len(errors)
            return " ".join(errors)
        
    @staticmethod    
    def is_displayed(player):
        return player.round_number == 1 


class Instructions2(Page):
    form_model = "player"
    form_fields = ["Task4", "Task5", "Task6"]

    @staticmethod
    def error_message(player, values):
        errors = []
        if values['Task4'] != C.CORRECT_ANSWERS['Task4']:
            errors.append('The answer to question 1 is incorrect.')
        if values['Task5'] != C.CORRECT_ANSWERS['Task5']:
            errors.append('The answer to question 2 is incorrect.')
        if values['Task6'] != C.CORRECT_ANSWERS['Task6']:
            errors.append('The answer to question 3 is incorrect.')

        if errors:
            player.num_errors += len(errors)
            return " ".join(errors)
        
    @staticmethod    
    def is_displayed(player):
        return player.round_number == 1   


class Instructions3(Page):
    form_model = "player"
    form_fields = ["Task7"]

    @staticmethod
    def error_message(player, values):
        errors = []
        if values['Task7'] != C.CORRECT_ANSWERS['Task7']:
            errors.append('The answer to question 1 is incorrect.')

        if errors:
            player.num_errors += len(errors)
            return " ".join(errors)
        
    @staticmethod    
    def is_displayed(player):
        return player.round_number == 1   


class Instructions4(Page):
    form_model = "player"
    form_fields = ["Task8", "Task9"]

    @staticmethod
    def error_message(player, values):
        errors = []
        if values['Task8'] != C.CORRECT_ANSWERS['Task8']:
            errors.append('The answer to question 1 is incorrect.')
        if values['Task9'] != C.CORRECT_ANSWERS['Task9']:
            errors.append('The answer to question 2 is incorrect.')    
        if errors:
            player.num_errors += len(errors)
            return " ".join(errors)
        
    @staticmethod    
    def is_displayed(player):
        return player.round_number == 1  
    
    
class UnderstandingErrors(Page):
    @staticmethod
    def is_displayed(player):
        return player.num_errors > 3
    
    
class UnderstoodCorrectly(Page):    
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1
    
    @staticmethod
    def before_next_page(player, timeout_happened):
        player.participant.wait_page_arrival = time.time() 


page_sequence = [ConsentForm, Instructions, UnderstandingErrors, Instructions1, UnderstandingErrors, Instructions2, UnderstandingErrors, Instructions3, UnderstandingErrors, Instructions4, UnderstandingErrors, UnderstoodCorrectly]




