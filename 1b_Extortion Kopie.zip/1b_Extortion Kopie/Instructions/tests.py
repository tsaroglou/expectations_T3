from otree.api import *
from . import *


class PlayerBot(Bot):
    def play_round(self):
        yield ConsentForm
        yield Instructions, dict(Task0=C.CORRECT_ANSWERS['Task0'])
        yield Instructions1, dict(Task1=C.CORRECT_ANSWERS['Task1'], Task2=C.CORRECT_ANSWERS['Task2'], Task3=C.CORRECT_ANSWERS['Task3'])
        yield Instructions2, dict(Task4=C.CORRECT_ANSWERS['Task4'], Task5=C.CORRECT_ANSWERS['Task5'], Task6=C.CORRECT_ANSWERS['Task6'])
        yield Instructions3, dict(Task7=C.CORRECT_ANSWERS['Task7'])
        yield Instructions4, dict(Task8=C.CORRECT_ANSWERS['Task8'], Task9=C.CORRECT_ANSWERS['Task9'])
        yield UnderstoodCorrectly