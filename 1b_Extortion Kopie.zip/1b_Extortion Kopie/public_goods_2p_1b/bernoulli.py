from random import random


def bernoulli(p = 0.5):
    num = 0

    while True:
        if random() < p:
            num += 1
        else:
            return num
    

if __name__ == '__main__':
    # the below code is to verify the working of bernoulli()
    base = 3
    num_trials = 100000
    results = []

    for _ in range(num_trials):
        results.append(base + bernoulli(0.5))

    counts = {}

    for result in results:
        if result in counts:
            counts[result] += 1
        else:
            counts[result] = 1

    print(counts)