
from os import environ

SESSION_CONFIGS = [
    dict(
        name='1b_Extortion',
        app_sequence=['Instructions', 'Game'],
        # app_sequence=['Game'],
        # app_sequence=["public_goods_2p_1b"],
        num_demo_participants=10,
        #use_browser_bots=True

    )
]

# if you set a property in SESSION_CONFIG_DEFAULTS, it will be inherited by all configs
# in SESSION_CONFIGS, except those that explicitly override it.
# the session config can be accessed from methods in your apps as self.session.config,
# e.g. self.session.config['participation_fee']

SESSION_CONFIG_DEFAULTS = dict(real_world_currency_per_point=0.0005, participation_fee=3.00, completion_url="https://app.prolific.com/submissions/complete?cc=C1O2OXLY", doc=""
)

PARTICIPANT_FIELDS = ["wait_page_arrival", "response_times", "contribute_start_time"]
SESSION_FIELDS = []

ROOMS = [
    dict(name="prolific", display_name="prolific"),
]
# ISO-639 code
# for example: de, fr, ja, ko, zh-hans
LANGUAGE_CODE = 'en'

# e.g. EUR, GBP, CNY, JPY
REAL_WORLD_CURRENCY_CODE = 'GBP'
USE_POINTS = True

ADMIN_USERNAME = 'admin'
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get('OTREE_ADMIN_PASSWORD')

DEMO_PAGE_INTRO_HTML = """ """

DEBUG= False

SECRET_KEY = '7903347557082'
